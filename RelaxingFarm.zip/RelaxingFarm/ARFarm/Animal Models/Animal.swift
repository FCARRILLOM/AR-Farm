//
//  Animal.swift
//  RelaxingFarm
//
//  Created by Fernando Carrillo on 6/18/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

class Animal: SCNNode {
    // variables
    var isSelected = false
    var currentState = "idle"
    
    // initializers
    override init() {
      super.init()
    }
    
    init(hitResult: ARHitTestResult) {
        super.init()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // creates node
    func createNode(hitResult: ARHitTestResult) {
    }
    
    // movements
    func walk(parentNode: SCNNode) {
    }
    
    @objc func stopWalk() {
    }
    
    func rotate() {
    }
    
    func eat() {
    }
    
    func stopEat() {
    }
    
    // other functions
    func selected() {
    }

}
