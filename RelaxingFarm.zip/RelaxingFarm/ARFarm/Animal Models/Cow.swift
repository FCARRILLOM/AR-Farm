//
//  Cow.swift
//  ARFarm
//
//  Created by Fernando Carrillo on 2/28/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

import Foundation
import SceneKit
import ARKit

class Cow: Animal {
    // atributos
    let cowScene = SCNScene(named: "art.scnassets/cow.scn")!
    
    // initializers
    override init() {
        super.init()
    }
    
    override init(hitResult: ARHitTestResult) {
        super.init()
        createNode(hitResult: hitResult)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // hace node de la vaca y lo retornea, en caso de que falle regresa una esfera roja
    override func createNode(hitResult: ARHitTestResult) {
        
        if let cowNode = cowScene.rootNode.childNode(withName: "Cow", recursively: true) {
            self.addChildNode(cowNode)
            
            self.position = SCNVector3(
                x: hitResult.worldTransform.columns.3.x,
                y: hitResult.worldTransform.columns.3.y + (self.boundingSphere.radius * 0.02 - 0.049),
                z: hitResult.worldTransform.columns.3.z)
            
            let randomY = Float(arc4random_uniform(8) + 1) * (Float.pi/4)
            
            self.eulerAngles = SCNVector3(-Float.pi/2, randomY, 0)
            
        } else { // si no funciona pone una esfera
            
            print("Cow error")
            
            let sphereNode = Sphere(hitResult: hitResult)
            self.geometry = sphereNode.geometry
        }
    }
    
    // movimientos
    
    // cambia de direccion
    override func rotate() {
        var direction = Float(arc4random_uniform(8) + 1)
        if(direction > 4) {
            direction -= 4
            direction *= -1
        }
        let randomY = direction * (Float.pi/4)
        self.runAction(
            SCNAction.rotateBy(x: 0, y: CGFloat(randomY), z: 0, duration: 1.8)
        )
    }
    
    // otros
    
    // animal selected, if it is selected, it changes color to red
    override func selected() {
        let material = SCNMaterial()
        if(isSelected) {
            material.diffuse.contents = UIColor.purple
            isSelected = false
        } else {
            material.diffuse.contents = UIColor.red
            isSelected = true
        }
        self.geometry?.materials = [material]
    }
}
