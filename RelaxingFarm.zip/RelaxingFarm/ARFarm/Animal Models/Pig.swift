//
//  Pig.swift
//  ARFarm
//
//  Created by Fernando Carrillo on 2/28/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

import Foundation
import SceneKit
import ARKit

class Pig: Animal {
    // atributos
    let pigScene = SCNScene(named: "art.scnassets/pig.dae")!
    var eatingAnimation = CAAnimation()
    var walkingAnimation = CAAnimation()
    
    // initializers
    override init() {
        super.init()
    }
    
    override init(hitResult: ARHitTestResult) {
        super.init()
        createNode(hitResult: hitResult)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    // hace node del puerco y lo retornea, en caso de que falle regresa una esfera roja
    override func createNode(hitResult: ARHitTestResult) {
        
        if let pigNode = pigScene.rootNode.childNode(withName: "Pig", recursively: true) {
            self.addChildNode(pigNode)
            
            //posicion
            self.position = SCNVector3(
                x: hitResult.worldTransform.columns.3.x,
                y: hitResult.worldTransform.columns.3.y + (self.boundingSphere.radius * 0.02 - 0.091),
                z: hitResult.worldTransform.columns.3.z)
            
            // scale
            self.scale = SCNVector3(x: 0.02, y: 0.02, z: 0.02)
            
            // cambia la direccion en la que veen al aparecer
            let randomY = Float(arc4random_uniform(8) + 1) * (Float.pi/4)
            self.eulerAngles = SCNVector3(0, randomY, 0)
            
        } else { // si no funciona pone una esfera
            print("Pig error")
            
            let sphereNode = Sphere(hitResult: hitResult)
            self.geometry = sphereNode.geometry
        }
    }
    
    // MARK: Animaciones
    // pig eating
    override func eat() {
        eatingAnimation = CAAnimation.animationWithSceneNamed("art.scnassets/pigEating.dae")!
        eatingAnimation.fadeInDuration = 0.3
        eatingAnimation.fadeOutDuration = 0.3
        eatingAnimation.repeatCount = 1
        self.addAnimation(eatingAnimation, forKey: "eating")
    }
    
    override func stopEat() {
        self.removeAnimation(forKey: "eating")
    }
    
    // pig walking
    override func walk(parentNode: SCNNode) {
        walkingAnimation = CAAnimation.animationWithSceneNamed("art.scnassets/pigWalking.dae")!
        
        walkingAnimation.fadeInDuration = 0.3
        walkingAnimation.fadeOutDuration = 0.3
        walkingAnimation.repeatCount = 2
        self.addAnimation(walkingAnimation, forKey: "walking")
        // convierte entre coordenadas del espacio y las coordenadas del node local
        var positionInParent = self.position
        var positionInSelf = self.convertPosition(positionInParent, from: parentNode)
        positionInSelf.z += 10
        positionInParent = parentNode.convertPosition(positionInSelf, from: self)

        self.runAction(
            SCNAction.move(to: positionInParent, duration: 4.5)
        )
    }
    
    override func stopWalk() {
        self.removeAnimation(forKey: "walking")
    }
    
    // cambia de direccion
    override func rotate() {
        var direction = Float(arc4random_uniform(8) + 1)
        if(direction > 4) {
            direction -= 4
            direction *= -1
        }
        let randomY = direction * (Float.pi/4)
        self.runAction(
            SCNAction.rotateBy(x: 0, y: CGFloat(randomY), z: 0, duration: 1.8)
        )
    }
    
    // animal selected, if it is selected, it changes color to red
    override func selected() {
        let material = SCNMaterial()
        if(isSelected) {
            material.diffuse.contents = UIColor.purple
            isSelected = false
        } else {
            material.diffuse.contents = UIColor.red
            isSelected = true
        }
        self.geometry?.materials = [material]
    }
    
}

// MARK: CoreAnimation

extension CAAnimation {
    class func animationWithSceneNamed(_ name: String) -> CAAnimation? {
        var animation: CAAnimation?
        if let scene = SCNScene(named: name) {
            scene.rootNode.enumerateChildNodes({ (child, stop) in
                if child.animationKeys.count > 0 {
                    animation = child.animation(forKey: child.animationKeys.first!)
                    stop.initialize(to: true)
                }
            })
        }
        return animation
    }
}
