//
//  Sheep.swift
//  ARFarm
//
//  Created by Fernando Carrillo on 3/11/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

import Foundation
import SceneKit
import ARKit

class Sheep: Animal {
    // atributos
    let sheepScene = SCNScene(named: "art.scnassets/sheep.dae")!
    var walkingAnimation = CAAnimation()

    // initializers
    override init() {
        super.init()
    }
    
    override init(hitResult: ARHitTestResult) {
        super.init()
        createNode(hitResult: hitResult)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // hace node del puerco y lo retornea, en caso de que falle regresa una esfera roja
    override func createNode(hitResult: ARHitTestResult) {
        
        if let sheepNode = sheepScene.rootNode.childNode(withName: "Sheep", recursively: true) {
            self.addChildNode(sheepNode)
            
            //posicion
            self.position = SCNVector3(
                x: hitResult.worldTransform.columns.3.x,
                y: hitResult.worldTransform.columns.3.y + (self.boundingSphere.radius * 0.02 - 0.11),
                z: hitResult.worldTransform.columns.3.z)
            
            // scale
            self.scale = SCNVector3(x: 0.02, y: 0.02, z: 0.02)
            
            // cambia la direccion en la que veen al aparecer
            let randomY = Float(arc4random_uniform(8) + 1) * (Float.pi/4)
            self.eulerAngles = SCNVector3(0, randomY, 0)
            
        } else { // si no funciona pone una esfera
            print("Sheep error")
            let sphereNode = Sphere(hitResult: hitResult)
            self.geometry = sphereNode.geometry
        }
    }
    
    // MARK: Animaciones

    // sheep walking
    override func walk(parentNode: SCNNode) {
        walkingAnimation = CAAnimation.animationWithSceneNamed("art.scnassets/sheepWalking.dae")!
        walkingAnimation.fadeInDuration = 0.4
        walkingAnimation.fadeOutDuration = 0.3
        walkingAnimation.repeatCount = 2
        
        self.addAnimation(walkingAnimation, forKey: "walking")
        // convierte entre coordenadas del espacio y las coordenadas del node local
        var positionInParent = self.position
        var positionInSelf = self.convertPosition(positionInParent, from: parentNode)
        positionInSelf.z += 10
        positionInParent = parentNode.convertPosition(positionInSelf, from: self)
        
        self.runAction(
            SCNAction.move(to: positionInParent, duration: 2.8)
        )
        
    }
    @objc override func stopWalk() {
        self.removeAnimation(forKey: "walking")
    }
    
    // sheep rotate
    override func rotate() {
        var direction = Float(arc4random_uniform(8) + 1)
        if(direction > 4) {
            direction -= 4
            direction *= -1
        }
        let randomY = direction * (Float.pi/4)
        self.runAction(
            SCNAction.rotateBy(x: 0, y: CGFloat(randomY), z: 0, duration: 1.8)
        )
    }
    
    // animal selected, if it is selected, it changes color to red
    override func selected() {
        let material = SCNMaterial()
        if(isSelected) {
            material.diffuse.contents = UIColor.purple
            isSelected = false
        } else {
            material.diffuse.contents = UIColor.red
            isSelected = true
        }
        self.geometry?.materials = [material]
    }
}

