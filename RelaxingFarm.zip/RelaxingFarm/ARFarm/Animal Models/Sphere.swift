//
//  Sphere.swift
//  ARFarm
//
//  Created by Fernando Carrillo on 2/28/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

import Foundation
import SceneKit
import ARKit

// se va a poner una esfera para marcar errores

class Sphere: Animal {
    
    // initializers
    override init() {
        super.init()
    }
    
    override init(hitResult: ARHitTestResult) {
        super.init()
        createNode(hitResult: hitResult)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func createNode(hitResult: ARHitTestResult) {
        let sphere = SCNSphere(radius: 0.05)
        
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.red
        
        sphere.materials = [material]
        
        let node = SCNNode()
        self.position = SCNVector3(
            x: hitResult.worldTransform.columns.3.x,
            y: hitResult.worldTransform.columns.3.y + (node.boundingSphere.radius),
            z: hitResult.worldTransform.columns.3.z)
        
        self.geometry = sphere
    }
    
}
