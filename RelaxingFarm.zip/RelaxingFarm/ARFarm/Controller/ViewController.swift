//
//  ViewController.swift
//  ARFarm
//
//  Created by Fernando Carrillo on 2/27/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

class ViewController: UIViewController, ARSCNViewDelegate, SCNSceneRendererDelegate {
    // variables
        // picker view
    var currentAnimal: String = "pig"
    var animalModelPicker: AnimalPicker!
    var pickerViewHidden = false
        // animal nodes
    var animalObjNodes = [Animal]()
    var animalNameList = [String]()
        //
    var planes = [UUID: VirtualPlane]()
    var selectMode = false
    
    // render
    var targetRenderTime: TimeInterval = 0

    // storyboard
    @IBOutlet var sceneView: ARSCNView!
    @IBOutlet weak var animalPicker: UIPickerView!
    @IBOutlet weak var hideShowButtonOutlet: UIButton!
    @IBOutlet weak var hideShowView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initView()
        initScene()
        
        // picker view for animals
        animalModelPicker = AnimalPicker()
        let y = animalPicker.frame.origin.y
        animalPicker.transform = CGAffineTransform(rotationAngle: CGFloat(-Float.pi / 2))
        animalPicker.frame = CGRect(x: 0, y: Int(y), width: Int(view.frame.width), height: 100)
        animalPicker.delegate = animalModelPicker
        animalPicker.dataSource = animalModelPicker
        
        // Show statistics such as fps and timing information
        //sceneView.showsStatistics = true
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal

        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }
    
    // MARK: - Initializers
    func initView() {
        // Set the view's delegate
        sceneView.delegate = self
        
        // agrega luz
        sceneView.autoenablesDefaultLighting = true
        
        // shows points in screen
        //self.sceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints]
    }
    func initScene() {
        let scene = SCNScene()
        sceneView.scene = scene
        sceneView.isPlaying = true
    }
    
    // MARK: - Plane detection
    // pone el plano
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        if let arPlaneAnchor = anchor as? ARPlaneAnchor {
            let plane = VirtualPlane(anchor: arPlaneAnchor)
            self.planes[arPlaneAnchor.identifier] = plane
            node.addChildNode(plane)
        }
    }
    // updatea el plano
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        if let arPlaneAnchor = anchor as? ARPlaneAnchor, let plane = planes[arPlaneAnchor.identifier] {
            plane.updateWithNewAnchor(arPlaneAnchor)
        }
    }
    // quita planos
    func renderer(_ renderer: SCNSceneRenderer, didRemove node: SCNNode, for anchor: ARAnchor) {
        if let arPlaneAnchor = anchor as? ARPlaneAnchor, let index = planes.index(forKey: arPlaneAnchor.identifier) {
            planes.remove(at: index)
        }
    }
    
    
    // MARK: - Animal actions
    
    // tap para poner el animal
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let touchLocation = touch.location(in: sceneView)
            
            if(selectMode) {
                // makes animal change color if selected
                let results = sceneView.hitTest(touchLocation, options: nil)
                if let hitResult = results.first {
                    //let selectedNode: Animal!
                    if let selectedNode = hitResult.node as? Animal {
                        selectedNode.selected()
                    } else {
                        print("select")
                    }
                }
                
            } else {
                // adds new animals to the scene
                let results = sceneView.hitTest(touchLocation, types: .existingPlaneUsingExtent)
                
                if let hitResult = results.first {
                    currentAnimal = animalModelPicker.getCurrentAnimal()
                    var newAnimal: Animal!
                    if currentAnimal == "pig" {
                        newAnimal = Pig(hitResult: hitResult)
                        animalNameList.append("pig")
                        
                    } else if currentAnimal == "cow" {
                        newAnimal = Cow(hitResult: hitResult)
                        animalNameList.append("cow")
                        
                    } else if currentAnimal == "sheep" {
                        newAnimal = Sheep(hitResult: hitResult)
                        animalNameList.append("sheep")
                    } else {
                        // error will show a red sphere
                        newAnimal = Sphere(hitResult: hitResult)
                        animalNameList.append("sphere")
                    }
                    animalObjNodes.append(newAnimal)
                    sceneView.scene.rootNode.addChildNode(newAnimal)
                }
            }
        }
    }
    
    // interacciones de animales
    func moveAnimals() {
        var index = 0
        var randomNumber: UInt32 = 0
        if(animalNameList.count > 0 && animalObjNodes.count > 0) {
            for animalNode in animalObjNodes {
                randomNumber = getRand(max: 100)
                
                if(randomNumber > 0 && randomNumber < 30) {
                    animalNode.currentState = "walking"
                    animalNode.walk(parentNode: sceneView.scene.rootNode)
                } else if (randomNumber >= 30 && randomNumber < 50) {
                    animalNode.currentState = "rotating"
                    animalNode.rotate()
                } else if (randomNumber >= 50 && randomNumber < 80) {
                    animalNode.currentState = "eating"
                    animalNode.eat()
                } else {
                    animalNode.currentState = "idle"
//                    animalNode.stopWalk()
//                    animalNode.stopEat()
                }
                
                index += 1
            }
        }

    }
    
    // get random number
    func getRand(max: UInt32) -> UInt32 {
        return arc4random_uniform(max) + 1
    }
    
    // MARK: - Render loop
    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        if(time > targetRenderTime) {
            moveAnimals()
            targetRenderTime = time + 4.5
        }
    }
    
    // MARK: - View buttons
    
    // hides and shows picker view for animal picker
    @IBAction func hideShowButton(_ sender: Any) {
        if(pickerViewHidden) {
            hideShowButtonOutlet.setTitle("Hide", for: .normal)
            
            UIView.animate(withDuration: 0.3) {
                self.hideShowView.center = CGPoint(x: self.hideShowView.center.x, y: self.hideShowView.center.y - 100)
                self.hideShowButtonOutlet.center = CGPoint(x: self.hideShowButtonOutlet.center.x, y: self.hideShowButtonOutlet.center.y - 100)
                self.animalPicker.center = CGPoint(x: self.animalPicker.center.x, y: self.animalPicker.center.y - 100)
            }
            
            pickerViewHidden = false
            
        } else {
            hideShowButtonOutlet.setTitle("Show", for: .normal)
            
            UIView.animate(withDuration: 0.3) {
                self.hideShowView.center = CGPoint(x: self.hideShowView.center.x, y: self.hideShowView.center.y + 100)
                self.hideShowButtonOutlet.center = CGPoint(x: self.hideShowButtonOutlet.center.x, y: self.hideShowButtonOutlet.center.y + 100)
                self.animalPicker.center = CGPoint(x: self.animalPicker.center.x, y: self.animalPicker.center.y + 100)
            }
            
            pickerViewHidden = true
        }
    }
    
    // borra todos los nodes del view y del array
    @IBAction func clearView(_ sender: Any) {
        for animal in animalObjNodes {
            animal.removeFromParentNode()
            animalObjNodes.remove(at: 0)
            animalNameList.remove(at: 0)
        }
        //print(animalNameList, animalObjNodes)
    }
    
    @IBAction func selectMode(_ sender: Any) {
        if(selectMode) {
            selectMode = false
        } else {
            selectMode = true
        }
    }
}

    // MARK: - ARSCNViewDelegate
    
/*
    // Override to create and configure nodes for anchors added to the view's session.
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let node = SCNNode()
     
        return node
    }
*/
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }




