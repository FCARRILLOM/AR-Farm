//
//  Wall.swift
//  ARFarm
//
//  Created by Fernando Carrillo on 3/21/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

import Foundation
import SceneKit

class Wall {
    func createWall(x: Float, z: Float, length: Float, width: Float) -> SCNNode {
        // cambia el width y length de la pared si al inicializar es 0
        var realWidth = width
        var realLength = length
        if(realWidth == 0) {
            realWidth = 0.008
        }
        if(realLength == 0) {
            realLength = 0.008
        }
        
        let wall = SCNBox(width: CGFloat(realWidth), height: 0.08, length: CGFloat(realLength), chamferRadius: 0)
        
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.brown
        
        wall.materials = [material]
        
        let node = SCNNode()
        node.position = SCNVector3(
            x: x,
            y: Float(0),
            z: z)
        node.geometry = wall
        
        return node
    }
}
