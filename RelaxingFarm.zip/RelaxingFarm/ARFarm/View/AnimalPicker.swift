//
//  AnimalPicker.swift
//  ARFarm
//
//  Created by Fernando Carrillo on 3/2/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

import UIKit

class AnimalPicker: UIPickerView {
    // data
    let animals =  ["pig", "cow", "sheep"]
    let animalsImage = ["pigPickerImage", "cowPickerImage", "sheepPickerImage"]
    var currentAnimal: String = "pig"
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        currentAnimal = animals[row]
    }
    
    func getCurrentAnimal() -> String {
        return currentAnimal
    }
    
}

extension AnimalPicker: UIPickerViewDataSource {
    // returns the number of 'columns' to display.
    public func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // returns the # of rows in each component..
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return animals.count
    }
}

extension AnimalPicker: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return animals[row]
    }
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 100
    }
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 90, height: 90))
        let myImageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 90, height: 90))
        
        switch row {
        case 0:
            myImageView.image = UIImage(named: animalsImage[row])
        case 1:
            myImageView.image = UIImage(named: animalsImage[row])
        case 2:
            myImageView.image = UIImage(named: animalsImage[row])
        default:
            myImageView.image = nil
            
            view.addSubview(myImageView)
            
            return view
        }
        view.addSubview(myImageView)
        return myImageView
    }
}


