//
//  VirtualPlane.swift
//  ARFarm
//
//  Created by Fernando Carrillo on 3/17/18.
//  Copyright © 2018 Fernando Carrillo. All rights reserved.
//

import Foundation
import SceneKit
import ARKit

class VirtualPlane: SCNNode {
    var anchor: ARPlaneAnchor!
    var planeGeometry: SCNPlane!
    let gridMaterial = SCNMaterial()
    var outerWalls = [SCNNode]()

    init(anchor: ARPlaneAnchor) {
        super.init()
        
        // (1) initialize anchor and geometry, set color for plane
        self.anchor = anchor
        self.planeGeometry = SCNPlane(width: CGFloat(anchor.extent.x), height: CGFloat(anchor.extent.z))
        gridMaterial.diffuse.contents = UIImage(named: "art.scnassets/grass.jpg")
        self.planeGeometry!.materials = [gridMaterial]
        
        // (2) create the SceneKit plane node. As planes in SceneKit are vertical, we need to initialize the y coordinate to 0,
        // use the z coordinate, and rotate it 90º.
        let planeNode = SCNNode(geometry: self.planeGeometry)
        planeNode.position = SCNVector3(anchor.center.x, 0, anchor.center.z)
        planeNode.transform = SCNMatrix4MakeRotation(-Float.pi / 2.0, 1.0, 0.0, 0.0)
        
        // (3) update the material representation for this plane
        updatePlaneMaterialDimensions()
        
        // outer limits
        let width = Float(self.planeGeometry.width)
        let height = Float(self.planeGeometry.height)
        setOuterBounds(width: width, height: height)
        
        // (4) add this node to our hierarchy.
        self.addChildNode(planeNode)
    }
    
    func updatePlaneMaterialDimensions() {
        // get material or recreate
        let material = self.planeGeometry.materials.first!
        // scale material to width and height of the updated plane
        let width = Float(self.planeGeometry.width)
        let height = Float(self.planeGeometry.height)
        material.diffuse.contentsTransform = SCNMatrix4MakeScale(width, height, 1.0)
    }
    
    func updateWithNewAnchor(_ anchor: ARPlaneAnchor) {
        // first, we update the extent of the plane, because it might have changed
        self.planeGeometry.width = CGFloat(anchor.extent.x)
        self.planeGeometry.height = CGFloat(anchor.extent.z)
        
        // now we should update the position (remember the transform applied)
        self.position = SCNVector3(anchor.center.x, 0, anchor.center.z)
        
        // update the material representation for this plane
        updatePlaneMaterialDimensions()
        
        // outer limits
        let width = Float(self.planeGeometry.width)
        let height = Float(self.planeGeometry.height)
        setOuterBounds(width: width, height: height)
    }
    
    // pone los objetos en las esquinas
    func setOuterBounds(width: Float, height: Float) {
        var boundingWall = Wall().createWall(x: 0, z: 0, length: 0, width: 0)
        let xOrigin: Float = -(width / 2)
        let zOrigin: Float = -(height / 2)
        
        for wall in outerWalls {
            wall.removeFromParentNode()
        }
        
        // pone en las paredes
        boundingWall = Wall().createWall(x: xOrigin, z: 0, length: height, width: 0)
        outerWalls.append(boundingWall)
        self.addChildNode(boundingWall)
        
        boundingWall = Wall().createWall(x: width/2, z: 0, length: height, width:  0)
        outerWalls.append(boundingWall)
        self.addChildNode(boundingWall)
        
        boundingWall = Wall().createWall(x: 0, z: zOrigin, length: 0, width: width)
        outerWalls.append(boundingWall)
        self.addChildNode(boundingWall)
        
        boundingWall = Wall().createWall(x: 0, z: height/2, length: 0, width: width)
        outerWalls.append(boundingWall)
        self.addChildNode(boundingWall)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
